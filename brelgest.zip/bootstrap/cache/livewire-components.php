<?php return array (
  'stat-cli-date-filter' => 'App\\Http\\Livewire\\StatCliDateFilter',
  'stat-prod-date-filter' => 'App\\Http\\Livewire\\StatProdDateFilter',
);