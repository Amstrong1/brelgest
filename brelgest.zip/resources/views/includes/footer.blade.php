{{-- <footer class="p-4 bg-slate-100 rounded-lg shadow-md md:flex md:items-center md:justify-center md:p-6 dark:bg-gray-800">
    <span class="text-sm text-gray-500 sm:text-center dark:text-gray-400">©
        <script>
            document.write(new Date().getFullYear());
        </script> <a target="blank" href="https://brelsoft.com/" class="hover:underline">BrelSoft
            Technologies</a>.
    </span>
</footer> --}}
