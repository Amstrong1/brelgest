<input x-data x-ref="input" x-init="new Pikaday({ field: $refs.input })" type="text" {{ $attributes }}>
