<!DOCTYPE html>
<html :class="{ 'theme-dark': dark }" x-data="data()" lang="en">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>BrelGest</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet"/>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/tailwind.output.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/Chart.min.css')); ?>"/>
</head>
<body>
<div
        class="flex h-screen bg-gray-50 dark:bg-gray-900"
        :class="{ 'overflow-hidden': isSideMenuOpen }"
>
    <!-- Desktop sidebar -->
    <?php echo $__env->make('includes.desktop-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Mobile sidebar -->
    <?php echo $__env->make('includes.mobile-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="flex flex-col flex-1 w-full">
        <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <main class="h-full overflow-y-auto">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</div>

<script src="<?php echo e(asset("assets/js/alpine.min.js")); ?>" defer></script>
<script src="<?php echo e(asset("assets/js/Chart.min.js")); ?>" defer></script>
<script src="<?php echo e(asset("assets/js/init-alpine.js")); ?>"></script>
<script src="<?php echo e(asset("assets/js/charts-lines.js")); ?>" defer></script>
<script src="<?php echo e(asset("assets/js/charts-pie.js")); ?>" defer></script>
</body>
</html>
<?php /**PATH /opt/lampp/htdocs/laravel-windmill-dashboard-main/resources/views/layouts/admin.blade.php ENDPATH**/ ?>