<?php $__env->startSection('content'); ?>
    <div class="container grid px-6 mx-auto">
        <h2 class="my-6 text-2xl font-semibold text-gray-700 dark:text-gray-200">
            Produit en rupture de stock
        </h2>

        <div class="w-full mb-8 overflow-hidden rounded-lg shadow-xs">
            <div class="w-full overflow-x-auto">
                <table class="w-full whitespace-no-wrap">
                    <thead>
                        <tr
                            class="text-xs font-semibold tracking-wide text-left text-gray-500 uppercase border-b dark:border-gray-700 bg-gray-50 dark:text-gray-400 dark:bg-gray-800">
                            <th class="px-4 py-3">Date du mouvement</th>
                            <th class="px-4 py-3">Produit</th>
                            <th class="px-4 py-3">Qte</th>
                            <th class="px-4 py-3">Estimation totale</th>
                            <th class="px-4 py-3">Observation</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y dark:divide-gray-700 dark:bg-gray-800">
                        <?php $__currentLoopData = $exits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-gray-700 dark:text-gray-400">
                                <td class="px-4 py-3">
                                    <?php echo e($exit->DateSortie); ?>

                                </td>
                                <td class="px-4 py-3 text-sm">
                                    <?php echo e($exit->LibProd); ?>

                                </td>
                                <td class="px-4 py-3 text-sm">
                                    <?php echo e($exit->Qtte); ?>

                                </td>
                                <td class="px-4 py-3 text-sm">
                                    <?php echo e(number_format($exit->MontantTotal, 0, '', ' ')); ?>

                                </td>
                                <td class="px-4 py-3 text-sm">
                                    <?php echo e($exit->Observation); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div
                class="grid px-4 py-3 text-xs font-semibold tracking-wide text-gray-500 uppercase border-t dark:border-gray-700 bg-gray-50 sm:grid-cols-9 dark:text-gray-400 dark:bg-gray-800">
                <span class="flex items-center col-span-3">
                    <?php if(!isset($_GET['page'])): ?>
                        <?php
                            $_GET['page'] = 1;
                        ?>
                    <?php endif; ?>
                    Showing <?php echo e($exits->count() * $_GET['page'] - 7); ?> - <?php echo e($exits->count() * $_GET['page']); ?> of
                    <?php echo e($exits_count->count()); ?>

                </span>
                <span class="col-span-2"></span>
                <!-- Pagination -->
                <span class="flex col-span-4 mt-2 sm:mt-auto sm:justify-end">
                    <nav aria-label="Table navigation">
                        <?php echo e($exits->links('components.pagination.default')); ?>

                    </nav>
                </span>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel-windmill-dashboard-main/resources/views/admin/stock/exits.blade.php ENDPATH**/ ?>