
<?php /**PATH /var/www/html/brelgest/resources/views/includes/footer.blade.php ENDPATH**/ ?>